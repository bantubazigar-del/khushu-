/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Frown, 
  Meh, 
  Heart, 
  Sparkles, 
  History,
  Info,
  Mic,
  Volume2,
  Settings2,
  Trash2
} from 'lucide-react';
import { 
  processDostInteraction,
  textToSpeech,
  Message, 
  UserPreferences 
} from './services/geminiService';

// Extend Window interface for SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const MOOD_ICONS: Record<string, any> = {
  happy: Smile,
  sad: Frown,
  angry: Frown,
  bored: Meh,
  neutral: Meh,
  excited: Sparkles,
  romantic: Heart,
};

const MOOD_COLORS: Record<string, string> = {
  happy: 'bg-yellow-100/10 text-yellow-500 border-yellow-500/20',
  sad: 'bg-blue-100/10 text-blue-500 border-blue-500/20',
  angry: 'bg-red-100/10 text-red-500 border-red-500/20',
  bored: 'bg-gray-100/10 text-gray-500 border-gray-500/20',
  neutral: 'bg-stone-100/10 text-stone-500 border-stone-500/20',
  excited: 'bg-orange-100/10 text-orange-500 border-orange-500/20',
  romantic: 'bg-pink-100/10 text-pink-500 border-pink-500/20',
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [usingBackupVoice, setUsingBackupVoice] = useState(false);
  const [preferences, setPreferences] = useState<UserPreferences>({
    likes: [],
    dislikes: [],
    moodHistory: [],
    preferredLanguage: 'Hinglish',
  });
  const [currentMood, setCurrentMood] = useState('neutral');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [handsFree, setHandsFree] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioContext = useRef<AudioContext | null>(null);
  const recognitionRef = useRef<any>(null);

  // Load preferences from local storage
  useEffect(() => {
    const savedPrefs = localStorage.getItem('dost_prefs');
    const savedMessages = localStorage.getItem('dost_messages');
    if (savedPrefs) setPreferences(JSON.parse(savedPrefs));
    if (savedMessages) setMessages(JSON.parse(savedMessages));
    
    const savedHandsFree = localStorage.getItem('dost_handsfree');
    if (savedHandsFree) setHandsFree(JSON.parse(savedHandsFree));

    // Pre-load voices for fallback
    // ...
  }, []);

  // Save changes
  useEffect(() => {
    localStorage.setItem('dost_prefs', JSON.stringify(preferences));
    localStorage.setItem('dost_messages', JSON.stringify(messages));
    localStorage.setItem('dost_handsfree', JSON.stringify(handsFree));
    scrollToBottom();
  }, [preferences, messages, handsFree]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  const playRawPCM = async (base64Audio: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        if (!audioContext.current) {
          audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        
        if (audioContext.current.state === 'suspended') {
          audioContext.current.resume();
        }

        const binaryString = atob(base64Audio);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        const pcm16 = new Int16Array(bytes.buffer);
        const float32 = new Float32Array(pcm16.length);
        for (let i = 0; i < pcm16.length; i++) {
          float32[i] = pcm16[i] / 32768.0;
        }

        const audioBuffer = audioContext.current.createBuffer(1, float32.length, 24000);
        audioBuffer.getChannelData(0).set(float32);

        const source = audioContext.current.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.current.destination);
        
        source.onended = () => {
          resolve();
        };

        source.start();
        setUsingBackupVoice(false);
      } catch (e) {
        console.error("Audio playback error:", e);
        reject(e);
      }
    });
  };

  const speakFallback = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    setUsingBackupVoice(true);
    
    // Stop any current speaking
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const preferredLang = preferences.preferredLanguage === 'Hindi' ? 'hi-IN' : 'en-IN';
    const voice = voices.find(v => v.lang === preferredLang) || voices.find(v => v.lang.startsWith('en'));
    
    if (voice) utterance.voice = voice;
    utterance.rate = 1.0;
    utterance.pitch = 1.1;
    
    window.speechSynthesis.speak(utterance);

    // Reset indicator after a while OR when it stops speaking
    utterance.onend = () => {
      setTimeout(() => setUsingBackupVoice(false), 2000);
      if (handsFree) toggleListening();
    };
  };

  const handleSend = async (overrideInput?: string) => {
    const text = overrideInput || inputValue;
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const interaction = await processDostInteraction([...messages, userMessage], preferences);
      const { responseText, analysis, functionCalls } = interaction;

      // Execute Browser/Media/WhatsApp Tool Calls
      if (functionCalls && functionCalls.length > 0) {
        functionCalls.forEach((call: any) => {
          const { name, args } = call;
          try {
            switch(name) {
              case 'openWebsite':
                window.open(args.url.startsWith('http') ? args.url : `https://${args.url}`, '_blank');
                break;
              case 'searchBrowser':
                window.open(`https://www.google.com/search?q=${encodeURIComponent(args.query)}`, '_blank');
                break;
              case 'searchYouTube':
                window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(args.query)}`, '_blank');
                break;
              case 'searchSpotify':
                window.open(`https://open.spotify.com/search/${encodeURIComponent(args.query)}`, '_blank');
                break;
              case 'sendWhatsAppMessage':
                const whatsappUrl = `https://web.whatsapp.com/send?phone=${args.phoneNumber}&text=${encodeURIComponent(args.message)}`;
                window.open(whatsappUrl, '_blank');
                break;
            }
          } catch (e) {
            console.error(`Tool execution error [${name}]:`, e);
          }
        });
      }

      if (analysis.mood) {
        setCurrentMood(analysis.mood);
        setPreferences(prev => ({
          ...prev,
          moodHistory: [...prev.moodHistory, { mood: analysis.mood, timestamp: Date.now() }],
          likes: [...new Set([...prev.likes, ...(analysis.newLikes || [])])],
          dislikes: [...new Set([...prev.dislikes, ...(analysis.newDislikes || [])])],
          preferredLanguage: analysis.detectedLanguage || prev.preferredLanguage
        }));
      }

      const modelMessage: Message = {
        role: 'model',
        content: responseText || "Ji bilkul, main abhi karta hoon!",
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, modelMessage]);

      if (autoSpeak && responseText) {
        const audioData = await textToSpeech(responseText);
        if (audioData) {
          await playRawPCM(audioData);
          if (handsFree) toggleListening();
        } else {
          speakFallback(responseText);
        }
      } else if (handsFree) {
        toggleListening();
      }
    } catch (error: any) {
      console.error(error);
      let content = "Yaar, network thoda down lag raha hai. Let's try again?";
      
      if (error?.message === "QUOTA_EXCEEDED") {
        content = "Arre yaar, main thoda thak gaya hoon (Quota Exceeded). Thodi der baad baat karte hain?";
      }

      const errorMessage: Message = {
        role: 'model',
        content,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMessage]);
      if (handsFree) toggleListening();
    } finally {
      setIsLoading(false);
    }
  };

  const toggleListening = () => {
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Browser speech recognition not supported.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = preferences.preferredLanguage === 'Hindi' ? 'hi-IN' : 'en-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = (e: any) => {
      console.error("Recognition error", e);
      setIsListening(false);
    };
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        handleSend(transcript);
      }
    };

    recognition.start();
  };

  const clearChat = () => {
    if (window.confirm('Saari yaadein mita dein?')) {
      setMessages([]);
      setPreferences(prev => ({ ...prev, moodHistory: [] }));
      localStorage.removeItem('dost_messages');
    }
  };

  const MoodIcon = MOOD_ICONS[currentMood] || Meh;

  return (
    <div className="flex h-screen bg-immersive-bg font-sans text-white overflow-hidden relative">
      <div className="atmosphere" />

      {/* Sidebar for Knowledge/Prefs (Integrated into rail style) */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.aside
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="fixed inset-y-0 left-0 w-80 glass-card z-50 p-8 flex flex-col border-r border-white/5"
          >
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-sm uppercase tracking-[0.2em] font-bold text-white/50">Yaadein</h2>
              <button onClick={() => setIsSidebarOpen(false)} className="text-white/30 hover:text-white transition-colors">
                <History className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 space-y-10 overflow-y-auto pr-2 custom-scrollbar">
              <section>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-[10px] uppercase tracking-widest text-indigo-400 font-black">Voice Mode</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
                    <span className="text-xs text-white/70">Auto-speak</span>
                    <button 
                      onClick={() => setAutoSpeak(!autoSpeak)}
                      className={`w-10 h-5 rounded-full transition-all relative ${autoSpeak ? 'bg-indigo-500' : 'bg-white/10'}`}
                    >
                      <motion.div 
                        animate={{ x: autoSpeak ? 22 : 2 }}
                        className="w-4 h-4 bg-white rounded-full absolute top-0.5"
                      />
                    </button>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/10">
                    <div className="flex flex-col">
                      <span className="text-xs text-white/70 font-bold">Hands-free</span>
                      <span className="text-[8px] text-white/30 uppercase tracking-tighter">Listen automatically</span>
                    </div>
                    <button 
                      onClick={() => setHandsFree(!handsFree)}
                      className={`w-10 h-5 rounded-full transition-all relative ${handsFree ? 'bg-indigo-500 shadow-[0_0_10px_#6366f1]' : 'bg-white/10'}`}
                    >
                      <motion.div 
                        animate={{ x: handsFree ? 22 : 2 }}
                        className="w-4 h-4 bg-white rounded-full absolute top-0.5"
                      />
                    </button>
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-[10px] uppercase tracking-widest text-indigo-400 font-black mb-4">Likes</h3>
                <div className="flex flex-wrap gap-2">
                  {preferences.likes.length > 0 ? preferences.likes.map((like, i) => (
                    <span key={i} className="px-3 py-1 bg-white/5 rounded-full text-xs text-white/70 border border-white/10 italic">
                      {like}
                    </span>
                  )) : <p className="text-xs text-white/30 italic">No preferences yet...</p>}
                </div>
              </section>

              <section>
                <h3 className="text-[10px] uppercase tracking-widest text-indigo-400 font-black mb-4">Mood Journey</h3>
                <div className="space-y-3">
                  {preferences.moodHistory.slice(-5).reverse().map((m, i) => (
                    <div key={i} className="flex justify-between text-xs py-2 border-b border-white/5">
                      <span className="capitalize text-white/70">{m.mood}</span>
                      <span className="text-white/20">{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <button 
              onClick={clearChat}
              className="mt-10 w-full py-4 flex items-center justify-center gap-2 text-white/40 hover:text-white transition-colors text-[10px] uppercase tracking-widest font-bold bg-white/5 rounded-2xl border border-white/10"
            >
              <Trash2 className="w-4 h-4" /> Clear Memories
            </button>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main UI Container */}
      <div className="flex-1 flex flex-col max-w-5xl mx-auto w-full relative z-10 px-6 py-8">
        
        {/* Top Nav */}
        <header className="flex justify-between items-center mb-12">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="group flex items-center gap-3"
            >
              <div className="p-2 glass-card hover:bg-white/10 rounded-full transition-all">
                <History className="w-5 h-5 text-indigo-400" />
              </div>
              <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-white/30 group-hover:text-white/60 transition-colors">Memory</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 shadow-[0_0_20px_rgba(0,0,0,0.3)]">
              <motion.div 
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="w-2 h-2 rounded-full bg-indigo-400 shadow-[0_0_10px_#818cf8]"
              />
              <span className="text-[11px] uppercase tracking-widest font-black text-indigo-300">Feeling: {currentMood}</span>
            </div>

            <AnimatePresence>
              {handsFree && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="bg-indigo-500/20 border border-indigo-500/30 rounded-full px-3 py-1.5 flex items-center gap-2 shadow-[0_0_15px_rgba(99,102,241,0.2)]"
                >
                  <Sparkles className="w-3 h-3 text-indigo-400" />
                  <span className="text-[9px] uppercase tracking-widest text-indigo-400 font-black">Hands-Free ON</span>
                </motion.div>
              )}
              
              {usingBackupVoice && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="bg-white/5 border border-white/5 rounded-full px-3 py-1.5 flex items-center gap-2"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span className="text-[9px] uppercase tracking-tighter text-amber-400/70 font-bold">Backup Voice Active</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setAutoSpeak(!autoSpeak)}
              className={`p-2 transition-all ${autoSpeak ? 'text-indigo-400' : 'text-white/20'}`}
              title="Toggle Auto-Speak"
            >
              <Volume2 className="w-5 h-5" />
            </button>
            <div className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold">
              {preferences.preferredLanguage} Mode
            </div>
          </div>
        </header>

        {/* Cinematic Conversation Area */}
        <main className="flex-1 flex flex-col items-center justify-center relative min-h-0">
          <div 
            ref={scrollRef}
            className="w-full flex-1 overflow-y-auto custom-scrollbar px-4 space-y-12 pb-20 mask-fade"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center gap-10">
                <motion.div 
                  animate={{ 
                    scale: isListening ? [1, 1.3, 1] : [1, 1.05, 1],
                    rotate: [0, 5, -5, 0],
                    boxShadow: isListening ? ["0 0 100px rgba(99, 102, 241, 0.3)", "0 0 150px rgba(99, 102, 241, 0.6)", "0 0 100px rgba(99, 102, 241, 0.3)"] : "0 0 100px rgba(99, 102, 241, 0.3)"
                  }}
                  transition={{ repeat: Infinity, duration: isListening ? 1.5 : 10, ease: "easeInOut" }}
                  className={`aura-sphere ${isListening ? 'ring-4 ring-indigo-500/50' : ''}`}
                />
                <div className="space-y-4 max-w-lg">
                  <h1 className="text-5xl font-serif italic text-white/95 leading-tight">
                    {isListening ? "Bol na dost, main sun raha hoon..." : "Namaste! Main hoon tera Dost."}
                  </h1>
                  <p className="text-lg text-white/40 italic">
                    {isListening ? "Voice recognized in " + preferences.preferredLanguage : "Bata na, kya haal hai aaj?"}
                  </p>
                </div>
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {messages.map((msg, idx) => {
                  const isLatest = idx === messages.length - 1;
                  return (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: isLatest ? 1 : 0.4, y: 0 }}
                      className={`flex flex-col items-center text-center gap-6 ${isLatest ? '' : 'scale-95 grayscale-[50%]'}`}
                    >
                      {msg.role === 'model' && isLatest && (
                         <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className={`aura-sphere transition-all duration-1000 mb-4 ${isListening ? 'scale-125 ring-4 ring-indigo-500/30' : ''}`} 
                        />
                      )}
                      
                      <div className={`max-w-3xl ${msg.role === 'user' ? 'text-indigo-300' : 'text-white'}`}>
                        {msg.role === 'user' ? (
                          <span className="text-xs uppercase tracking-widest font-black opacity-30 block mb-2">Tumne Kaha</span>
                        ) : null}
                        <p className={`font-serif italic leading-relaxed ${msg.role === 'model' ? 'text-4xl' : 'text-xl opacity-80'}`}>
                          {msg.role === 'model' ? `“${msg.content}”` : msg.content}
                        </p>
                        {msg.role === 'model' && isLatest && (
                          <button 
                            onClick={async () => {
                              const audioData = await textToSpeech(msg.content);
                              if (audioData) {
                                playRawPCM(audioData);
                              } else {
                                speakFallback(msg.content);
                              }
                            }}
                            className="mt-4 text-white/20 hover:text-white transition-colors"
                          >
                            <Volume2 className="w-5 h-5 mx-auto" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}
            
            {isLoading && (
              <div className="flex flex-col items-center gap-8">
                 <motion.div 
                  animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="aura-sphere bg-indigo-500/20" 
                />
                <p className="text-xs uppercase tracking-[0.4em] text-white/20 animate-pulse">Sun raha hoon...</p>
              </div>
            )}
          </div>
        </main>

        {/* Floating Controls Bar */}
        <footer className="mt-auto px-4 pb-4">
          <div className="glass-card rounded-[2rem] p-4 flex items-center gap-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/5">
            <button 
              onClick={toggleListening}
              className={`p-4 rounded-2xl transition-all ${
                isListening ? 'bg-indigo-500 text-white animate-pulse' : 'bg-white/5 text-white/40 hover:bg-white/10'
              }`}
              id="voice-btn"
            >
              <Mic className="w-6 h-6" />
            </button>
            <input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={isListening ? "Sun raha hoon..." : "Kuch bhi bolo..."}
              className="flex-1 bg-transparent border-none focus:ring-0 px-4 text-lg placeholder:text-white/20 outline-none"
              id="message-input"
            />
            
            <div className="hidden sm:flex gap-2">
              {['Kaisa hai?', 'Mood kharab hai', 'Story sunao', 'Shayari humein'].map((chip) => (
                <button
                  key={chip}
                  onClick={() => {
                    setInputValue(chip);
                    handleSend(chip);
                  }}
                  className="px-4 py-1.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all text-white/50 hover:text-white"
                >
                  {chip}
                </button>
              ))}
            </div>

            <button 
              onClick={() => handleSend()}
              disabled={!inputValue.trim() || isLoading}
              className={`px-8 py-3 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-lg ${
                inputValue.trim() && !isLoading 
                  ? 'bg-indigo-500 text-white hover:bg-indigo-400 active:scale-95' 
                  : 'bg-white/5 text-white/20 pointer-events-none'
              }`}
            >
              Send
            </button>
          </div>
        </footer>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.05); border-radius: 10px; }
        .mask-fade {
          mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
        }
      `}</style>
    </div>
  );
}
