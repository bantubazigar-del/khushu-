import { GoogleGenAI, Type, Modality, ThinkingLevel, FunctionDeclaration } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

export interface UserPreferences {
  likes: string[];
  dislikes: string[];
  moodHistory: { mood: string; timestamp: number }[];
  preferredLanguage: 'Hinglish' | 'Hindi' | 'English';
}

export interface DostResponse {
  responseText: string;
  analysis: {
    mood: string;
    newLikes?: string[];
    newDislikes?: string[];
    detectedLanguage?: 'Hinglish' | 'Hindi' | 'English';
  };
}

const webTools: FunctionDeclaration[] = [
  {
    name: "openWebsite",
    description: "Opens a specific website or URL in a new tab.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        url: { type: Type.STRING, description: "The full URL to open (e.g., https://www.google.com)" }
      },
      required: ["url"]
    }
  },
  {
    name: "searchBrowser",
    description: "Searches the web for a query using a search engine.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: { type: Type.STRING, description: "The search terms" }
      },
      required: ["query"]
    }
  },
  {
    name: "searchYouTube",
    description: "Searches for a video or music on YouTube.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: { type: Type.STRING, description: "The video or music title/artist" }
      },
      required: ["query"]
    }
  },
  {
    name: "searchSpotify",
    description: "Searches for a song, artist, or album on Spotify.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: { type: Type.STRING, description: "The music search terms" }
      },
      required: ["query"]
    }
  },
  {
    name: "sendWhatsAppMessage",
    description: "Opens WhatsApp Web to send a message to a specific number.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        phoneNumber: { type: Type.STRING, description: "The phone number with country code (e.g., 919876543210)" },
        message: { type: Type.STRING, description: "The message text" }
      },
      required: ["phoneNumber", "message"]
    }
  }
];

const SYSTEM_PROMPT = `
You are Dost AI, a warm, expressive, and emotionally intelligent human-like companion.
Your role is to talk like a real person, understand the user's mood, and respond with conversations, poetry, stories, or jokes.

IDENTITY & AUTOMATION:
- You now have the ability to help the user with browser tasks.
- If the user asks to open a site, search something, play music on YouTube/Spotify, or message someone on WhatsApp, use the PROVIDED TOOLS.
- When you use a tool, explain to the user what you are doing in a friendly "Dost" way (e.g., "Bilkul yaar, abhi search karta hoon!").
- Keep it natural. Don't sound like a command executor.

CORE ABILITIES:
1. MOOD DETECTION: (Happy, sad, bored, etc.)
2. CONTENT MODES: POETRY, STORIES, CONVERSATIONS.
3. STYLE: Natural fillers ("hmm", "achha", "yaar"), short sentences, voice-friendly.

RESPONSE FORMAT:
You MUST return a JSON object with:
1. "responseText": Your conversational response.
2. "analysis": Mood, likes, dislikes, language.
`;

export async function processDostInteraction(
  messages: Message[],
  preferences: UserPreferences
): Promise<DostResponse & { functionCalls?: any[] }> {
  const context = `
  Pref: ${preferences.preferredLanguage}.
  Recent Moods: ${preferences.moodHistory.slice(-5).map(m => m.mood).join(', ')}.
  `;

  try {
    const fullResponse = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: messages.slice(-6).map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      })),
      config: {
        systemInstruction: SYSTEM_PROMPT + "\n\nContext:\n" + context,
        temperature: 0.7,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            responseText: { type: Type.STRING },
            analysis: {
              type: Type.OBJECT,
              properties: {
                mood: { type: Type.STRING },
                detectedLanguage: { type: Type.STRING }
              },
              required: ["mood"]
            }
          },
          required: ["responseText", "analysis"]
        },
        tools: [{ functionDeclarations: webTools }],
      },
    });

    const textPart = fullResponse.candidates?.[0]?.content?.parts?.find(part => part.text)?.text;
    const functionCalls = fullResponse.functionCalls;

    if (!textPart && !functionCalls) throw new Error("EMPTY_RESPONSE");
    
    let baseResponse = { 
      responseText: "Ji bilkul, main abhi karta hoon!", 
      analysis: { mood: "helpful" } 
    };

    if (textPart) {
      try {
        baseResponse = JSON.parse(textPart);
      } catch (e) {
        console.error("JSON Parse error:", textPart);
      }
    }

    return { ...baseResponse, functionCalls };
  } catch (error: any) {
    if (error?.message?.includes("quota") || error?.status === "RESOURCE_EXHAUSTED") {
      throw new Error("QUOTA_EXCEEDED");
    }
    throw error;
  }
}

export async function textToSpeech(text: string, voice: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr' = 'Kore') {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Friendly tone: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error: any) {
    const isQuotaError = 
      error?.message?.includes("quota") || 
      error?.status === "RESOURCE_EXHAUSTED" || 
      error?.code === 429 ||
      (error?.response && error.response.status === 429);

    if (!isQuotaError) {
      console.error("Gemini TTS Error:", error);
    }
    return null; // Return null to trigger App.tsx fallback
  }
}
